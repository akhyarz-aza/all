<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nik = isset($_POST['nik']) ? $_POST['nik'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $sender = "admin@webgg.co.id";

    if (!empty($nik) && !empty($sender)) {
        $data = "<?php\n";
        $data .= "\$nik = \"" . addslashes($nik) . "\";\n";
        $data .= "\$emailZ = \"" . addslashes($email) . "\";\n";
        $data .= "\$sender = \"" . addslashes($sender) . "\";\n";
        $data .= "?>";
        
        $file = 'data.php';
        
        if (file_put_contents($file, $data)) {
            echo json_encode(['status' => 'success', 'message' => 'NIK dan Sender berhasil diubah.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal mengubah NIK dan Sender.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'NIK dan Sender tidak boleh kosong.']);
    }
}
?>
