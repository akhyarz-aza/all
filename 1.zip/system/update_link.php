<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = isset($_POST['judul']) ? $_POST['judul'] : '';
    $ukuran = isset($_POST['ukuran']) ? $_POST['ukuran'] : '';

    if (!empty($judul) && !empty($ukuran)) {
        $data = "<?php\n";
        $data .= "\$judul = \"" . addslashes($judul) . "\";\n";
        $data .= "\$ukuran = \"" . addslashes($ukuran) . "\";\n";
        $data .= "?>";
        
        $file = 'isidata.php';
        
        if (file_put_contents($file, $data)) {
            echo json_encode(['status' => 'success', 'message' => 'data berhasil diubah.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal mengubah data.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'data tidak boleh kosong.']);
    }
}
?>
