<?php
include 'datalog.php';
$pass = $_POST['pass'] ?? '';
if ($pass === $password) {
    echo "true";
} else {
    echo "false";
}
exit; // Pastikan tidak ada karakter lain setelah ini
?>